# Guia para generar APK — Vitalis AI

## Requisitos

1. Una computadora con Node.js instalado ([nodejs.org](https://nodejs.org))
2. Cuenta gratuita en [expo.dev](https://expo.dev)

---

## Pasos rapidos (solo 4 comandos)

### 1. Descarga el proyecto de Replit
En Replit → panel de archivos → tres puntos (`···`) → **Download as ZIP** → descomprimelo

### 2. Abre terminal en la carpeta del proyecto y ejecuta:

```bash
npm install -g eas-cli
eas login
npm install
eas build -p android --profile preview
```

- `eas login` te pide usuario/contraseña de expo.dev
- El build tarda 10-15 minutos en los servidores de Expo
- Al terminar te da un **enlace de descarga** del `.apk`

### 3. Instala el APK en tu Android
1. Descarga el `.apk` del enlace
2. Envialo a tu celular (cable, email, Drive, etc.)
3. En Android: Ajustes → Seguridad → activa **"Fuentes desconocidas"**
4. Abre el `.apk` para instalar

---

## Configuracion ya incluida

| Archivo | Descripcion |
|---------|-------------|
| `eas.json` | Perfiles de build (preview=APK, production=AAB) |
| `app.json` | Nombre, iconos, permisos Android/iOS, plugins |
| Permisos Android | Camara, ubicacion GPS, almacenamiento, vibracion |
| Permisos iOS | Camara, fotos, ubicacion, acelerometro |

---

## Build para Google Play Store

```bash
eas build -p android --profile production
```

Genera un `.aab` (Android App Bundle) listo para subir a Google Play Console.

---

## Build para iOS (requiere Apple Developer, $99/año)

```bash
eas build -p ios --profile preview
```

---

## Notas

- El APK se genera en los servidores de Expo (EAS), **no en tu computadora**
- El primer build puede tardar mas (15-20 min) por la cache
- Para actualizaciones sin reinstalar: `eas update --branch production`
- Google Sign-In es opcional — la app funciona sin el (modo invitado)
